// Variables globales
let usuarioActual = null;
let grafica = null;

document.addEventListener("DOMContentLoaded", () => {
  // Mostrar login al cargar la página
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('registerForm').style.display = 'none';
  document.getElementById('appContent').style.display = 'none';
  document.getElementById('graficaVentana').style.display = 'none';
});

function toggleRegister(mostrarLogin) {
  document.getElementById('loginForm').style.display = mostrarLogin ? 'block' : 'none';
  document.getElementById('registerForm').style.display = mostrarLogin ? 'none' : 'block';
}

function mostrarMensaje(mensaje, color = 'black') {
  const mensajeEl = document.getElementById('mensaje');
  mensajeEl.textContent = mensaje;
  mensajeEl.style.color = color;
  mensajeEl.style.opacity = 1;
  setTimeout(() => {
    mensajeEl.style.opacity = 0;
  }, 3000);
}

function obtenerUsuarios() {
  return JSON.parse(localStorage.getItem('usuarios')) || [];
}

function guardarUsuarios(usuarios) {
  localStorage.setItem('usuarios', JSON.stringify(usuarios));
}

function login() {
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value.trim();
  const usuarios = obtenerUsuarios();

  const usuario = usuarios.find(u => u.username === username && u.password === password);

  if (usuario) {
    usuarioActual = username;
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('appContent').style.display = 'block';
    document.getElementById('usuarioNombre').textContent = usuarioActual;
    cargarDatos();
    limpiarCamposLogin();
  } else {
    mostrarMensaje('Credenciales incorrectas', 'red');
  }
}

function limpiarCamposLogin() {
  document.getElementById('username').value = '';
  document.getElementById('password').value = '';
}

function register() {
  const username = document.getElementById('newUsername').value.trim();
  const password = document.getElementById('newPassword').value.trim();
  const usuarios = obtenerUsuarios();

  if (!username || !password) {
    mostrarMensaje('Por favor, completa todos los campos', 'red');
    return;
  }

  if (usuarios.find(u => u.username === username)) {
    mostrarMensaje('Usuario ya registrado', 'red');
    return;
  }

  usuarios.push({ username, password });
  guardarUsuarios(usuarios);
  mostrarMensaje('Registro exitoso', 'green');
  toggleRegister(true);
  limpiarCamposRegistro();
}

function limpiarCamposRegistro() {
  document.getElementById('newUsername').value = '';
  document.getElementById('newPassword').value = '';
}

function logout() {
  usuarioActual = null;
  document.getElementById('appContent').style.display = 'none';
  document.getElementById('loginForm').style.display = 'block';
  if (grafica) {
    grafica.destroy();
    grafica = null;
  }
  cerrarGrafica();
}

function cargarDatos() {
  const datos = JSON.parse(localStorage.getItem(usuarioActual)) || {
    saldo: 0,
    movimientos: [],
    metas: []
  };

  document.getElementById('saldo').textContent = datos.saldo.toFixed(2);
  mostrarMovimientos(datos.movimientos);
  mostrarMetas(datos.metas);
  mostrarInformeGastos(datos.movimientos);
}

function guardarDatos(datos) {
  localStorage.setItem(usuarioActual, JSON.stringify(datos));
}

function ingresar() {
  const cantidad = parseFloat(document.getElementById('ingreso').value);
  const descripcion = document.getElementById('descIngreso').value.trim() || 'Ingreso';

  if (isNaN(cantidad) || cantidad <= 0) {
    mostrarMensaje('Cantidad inválida para ingreso', 'red');
    return;
  }

  const datos = JSON.parse(localStorage.getItem(usuarioActual)) || {
    saldo: 0,
    movimientos: [],
    metas: []
  };

  datos.saldo += cantidad;
  datos.movimientos.push({ tipo: 'ingreso', cantidad, descripcion, fecha: new Date().toLocaleString() });
  guardarDatos(datos);
  cargarDatos();

  document.getElementById('ingreso').value = '';
  document.getElementById('descIngreso').value = '';
}

function sacar() {
  const cantidad = parseFloat(document.getElementById('retiro').value);
  const descripcion = document.getElementById('descripcionRetiro').value.trim() || 'Gasto';

  if (isNaN(cantidad) || cantidad <= 0) {
    mostrarMensaje('Cantidad inválida para retiro', 'red');
    return;
  }

  const datos = JSON.parse(localStorage.getItem(usuarioActual)) || {
    saldo: 0,
    movimientos: [],
    metas: []
  };

  if (cantidad > datos.saldo) {
    mostrarMensaje('No tienes saldo suficiente', 'red');
    return;
  }

  datos.saldo -= cantidad;
  datos.movimientos.push({ tipo: 'retiro', cantidad, descripcion, fecha: new Date().toLocaleString() });
  guardarDatos(datos);
  cargarDatos();

  document.getElementById('retiro').value = '';
  document.getElementById('descripcionRetiro').value = '';
}

function crearMeta() {
  const nombre = document.getElementById('nombreMeta').value.trim();
  const monto = parseFloat(document.getElementById('montoMeta').value);

  if (!nombre || isNaN(monto) || monto <= 0) {
    mostrarMensaje('Datos inválidos para la meta', 'red');
    return;
  }

  const datos = JSON.parse(localStorage.getItem(usuarioActual)) || {
    saldo: 0,
    movimientos: [],
    metas: []
  };

  datos.metas.push({ nombre, monto, completada: false });
  guardarDatos(datos);
  cargarDatos();

  document.getElementById('nombreMeta').value = '';
  document.getElementById('montoMeta').value = '';
}

function mostrarMovimientos(movimientos) {
  const contenedor = document.getElementById('movimientos');
  contenedor.innerHTML = '<h3>Movimientos</h3>' + movimientos.map(m => `
    <div class="movimiento ${m.tipo}">
      ${m.fecha} - ${m.descripcion}: $${m.cantidad.toFixed(2)}
    </div>
  `).join('');
}

function mostrarMetas(metas) {
  const contenedor = document.getElementById('listaMetas');
  const datos = JSON.parse(localStorage.getItem(usuarioActual));

  contenedor.innerHTML = '<h3>Metas de Ahorro</h3>' + metas.map((meta) => {
    const ingresos = datos.movimientos.filter(m => m.tipo === 'ingreso').reduce((acc, m) => acc + m.cantidad, 0);
    const porcentaje = Math.min((ingresos / meta.monto) * 100, 100);
    const completada = porcentaje >= 100;
    if (completada && !meta.completada) meta.fechaCompletada = new Date().toLocaleDateString();
    meta.completada = completada;
    return `
      <div class="meta">
        <strong>${meta.nombre}</strong> - $${meta.monto.toFixed(2)} ${meta.completada ? '(Completada el ' + meta.fechaCompletada + ')' : ''}
        <div class="progress">
          <div class="progress-bar" style="width:${porcentaje}%"></div>
        </div>
      </div>`;
  }).join('');
  guardarDatos(datos);
}

function mostrarInformeGastos(movimientos) {
  const contenedor = document.getElementById('informeGastos');
  const gastos = movimientos.filter(m => m.tipo === 'retiro');
  if (gastos.length === 0) {
    contenedor.innerHTML = '<p>No hay gastos registrados.</p>';
    return;
  }
  contenedor.innerHTML = gastos.map(g => `<div>${g.fecha} - ${g.descripcion}: $${g.cantidad.toFixed(2)}</div>`).join('');
}

function mostrarGraficaSaldo() {
  const datos = JSON.parse(localStorage.getItem(usuarioActual)) || { movimientos: [] };
  if (datos.movimientos.length === 0) {
    mostrarMensaje('No hay movimientos para mostrar en la gráfica', 'red');
    return;
  }

  const etiquetas = datos.movimientos.map(m => m.fecha);
  const valores = datos.movimientos.reduce((acc, mov, i) => {
    acc.push((acc[i - 1] || 0) + (mov.tipo === 'ingreso' ? mov.cantidad : -mov.cantidad));
    return acc;
  }, []);

  const ctx = document.getElementById('graficaSaldo').getContext('2d');
  if (grafica) grafica.destroy();
  grafica = new Chart(ctx, {
    type: 'line',
    data: {
      labels: etiquetas,
      datasets: [{
        label: 'Saldo en el tiempo',
        data: valores,
        fill: false,
        borderColor: 'blue',
        tension: 0.1,
        pointRadius: 3
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { display: true, title: { display: true, text: 'Fecha' } },
        y: { display: true, title: { display: true, text: 'Saldo ($)' } }
      }
    }
  });

  document.getElementById('graficaVentana').style.display = 'block';
}

function cerrarGrafica() {
  document.getElementById('graficaVentana').style.display = 'none';
}

function descargarInformePDF() {
  const { jsPDF } = window.jspdf; // Obtener jsPDF del objeto global

  const datos = JSON.parse(localStorage.getItem(usuarioActual)) || { movimientos: [] };
  const gastos = datos.movimientos.filter(m => m.tipo === 'retiro');
  if (gastos.length === 0) {
    mostrarMensaje('No hay gastos para generar el informe PDF', 'red');
    return;
  }

  const doc = new jsPDF();
  doc.setFontSize(18);
  doc.text('Informe de Gastos', 10, 20);

  doc.setFontSize(12);
  let y = 30;
  gastos.forEach(g => {
    doc.text(`${g.fecha} - ${g.descripcion}: $${g.cantidad.toFixed(2)}`, 10, y);
    y += 10;
    if (y > 280) {
      doc.addPage();
      y = 20;
    }
  });

  doc.save('informe_gastos.pdf');
}
